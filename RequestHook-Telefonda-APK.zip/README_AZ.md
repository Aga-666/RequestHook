# RequestHook

Bu layihə Android Studio ilə APK yığmaq üçün hazırlanıb.

## APK yaratmaq
1. Android Studio-nu aç.
2. **Open** seç və bu qovluğu göstər.
3. Gradle sync-in bitməsini gözlə.
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** seç.
5. APK adətən `app/build/outputs/apk/debug/app-debug.apk` altında yaranır.

Bu nümunə öz API/server-in üçün HTTP test/jurnal interfeysidir; başqa tətbiqlərin qorunan trafikini gizli şəkildə ələ keçirmək üçün nəzərdə tutulmayıb.
