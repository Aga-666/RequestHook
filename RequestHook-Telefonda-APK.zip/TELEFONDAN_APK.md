# Telefonda APK yığmaq

1. ZIP-i açıb faylları GitHub-da yeni repository-yə yüklə.
2. Repository-də **Actions** bölməsinə gir.
3. **Build RequestHook APK** workflow-unu seç.
4. **Run workflow** düyməsinə bas.
5. Build bitəndə workflow-un nəticəsində **Artifacts** bölməsindən `RequestHook-debug-apk` faylını yüklə.
6. ZIP-dən çıxar və `app-debug.apk`-ni telefonda quraşdır.

Bu workflow Android SDK və Gradle ilə debug APK yaradır.
