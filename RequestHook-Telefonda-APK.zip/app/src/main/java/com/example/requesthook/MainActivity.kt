package com.example.requesthook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class RequestItem(val method: String, val url: String, val status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                RequestHookScreen()
            }
        }
    }
}

@Composable
fun RequestHookScreen() {
    var url by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("GET") }
    var output by remember { mutableStateOf("Hazırdır. Öz API/server-in üçün test sorğusu göndərə bilərsən.") }
    var requests by remember { mutableStateOf(listOf<RequestItem>()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("RequestHook", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(6.dp))
        Text("HTTP test və sorğu jurnal tətbiqi")

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("URL") },
            placeholder = { Text("https://example.com/api") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    method = "GET"
                    output = "GET seçildi"
                },
                modifier = Modifier.weight(1f)
            ) { Text("GET") }

            Spacer(Modifier.width(8.dp))

            Button(
                onClick = {
                    method = "POST"
                    output = "POST seçildi"
                },
                modifier = Modifier.weight(1f)
            ) { Text("POST") }
        }

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                if (url.isBlank()) {
                    output = "Əvvəl URL daxil et."
                } else {
                    requests = listOf(
                        RequestItem(method, url, "Queued")
                    ) + requests
                    output = "$method sorğusu test siyahısına əlavə edildi."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Sorğunu əlavə et")
        }

        Spacer(Modifier.height(12.dp))
        Text(output)

        Spacer(Modifier.height(12.dp))
        Text("Sorğu jurnalı", style = MaterialTheme.typography.titleMedium)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(requests) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${item.method}  •  ${item.status}")
                        Text(item.url)
                    }
                }
            }
        }
    }
}
